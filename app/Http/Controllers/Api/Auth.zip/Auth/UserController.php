<?php

//namespace App\Http\Controllers\Api\Auth;
//use App\Http\Controllers\Api\ResponseController;
namespace App\Http\Controllers\Api\Auth;


use App\Http\Controllers\Api\ResponseController;
use App\Models\User;
use GuzzleHttp\Promise\Create;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Hash;

class UserController extends ResponseController
{
        use FieldTrait;


  

}
